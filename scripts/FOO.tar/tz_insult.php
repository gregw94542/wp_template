<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://example.com
 * @since             1.0.0
 * @package           Tz_Insult
 *
 * @wordpress-plugin
 * Plugin Name:       TZ_Insult
 * Plugin URI:        http://networkistics.com
 * Description:       Relentlessly insult the user
 * Version:           1.0.0
 * Author:            Greg Wong
 * Author URI:        http://Networkistics.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       plugin-name
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-plugin-name-activator.php
 */
function activate_tz_insult() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/tz_insult-activator.php';
	tz_insult_Activate::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-plugin-name-deactivator.php
 */
function deactivate_tz_insult() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/tz_insult-deactivator.php';
	Tz_Insult_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_tz_insult' );
register_deactivation_hook( __FILE__, 'deactivate_tz_insult' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/tz_insult.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_tz_insult() {

	//$plugin = new Tz_Insult(); - Greg
	$plugin = new tz_insult();
	$plugin->run();
	Add_shortcode('TZ_INSULT', array('tz_insult', 'alive'));
?>

<?php


}
run_tz_insult();
